DIGITAL GARDENS RIDGE-WIND HISTORICAL SCREEN
Source: https://open-meteo.com/en/docs/historical-weather-api
ERA5: https://doi.org/10.24381/cds.adbb2d47
Location points are not turbine locations, some are APPROXIMATE.
Hourly series is modeled reanalysis, not station observations or bankable wind measurements.
Wind over ridges can be underestimated because the ERA5 / IFS grids average terrain.
The request URL, grid coordinate, returned elevation, original JSON, and missing counts
are recorded in provenance_manifest_<model>.json. Local observations and mesoscale micrositing
plus on-site measurements are needed for construction assessment.
A nearby wind project's existing BC Hydro PPA does not imply its power is available.
